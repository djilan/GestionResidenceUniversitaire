package com.logement.mvc.controllers;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.logement.mvc.entities.Residence;
import com.logement.mvc.services.IResidenceService;
@Controller
@RequestMapping(value="/residence")
public class ResidenceController {

	@Autowired
	private IResidenceService residenceService;
	
	@RequestMapping(value="/")
	public String residence(Map<String , Object >map) {
		Residence residences=new Residence();
		map.put("residences", residences);
		map.put("residencesList", residenceService.selectAll());
		return"residence/residence";
	}
	@RequestMapping(value="/nouvelle", method=RequestMethod.GET)
	public String addResidence(Model model) {

        Residence residence=new Residence();
		model.addAttribute("residence", residence);
		return"residence/AddResidence";
	}
	
	@RequestMapping(value="/nouvelle", method=RequestMethod.POST)
	public String enregistrerResidence(Residence residence) {
		
		if(residence.getIdResidence() !=null) {
			residenceService.update(residence);
		}else {
			residenceService.save(residence);
		}
    
		return"redirect:/residence/";
	}
	
	@RequestMapping(value="/modifier/{idResidence}")
	public String modifierEtudiant(Model model, @PathVariable Long idResidence) {
		
		if(idResidence !=null) {
			Residence residence=residenceService.getById(idResidence);
			if(residence !=null) {
				model.addAttribute("residence", residence);
			}
		}
		return "residence/AddResidence";
	}
	@RequestMapping(value="/supprimer/{idResidence}")
	public String supprimerEtudiant(Model model, @PathVariable Long idResidence) {
		if(idResidence!=null) {
			Residence residence=residenceService.getById(idResidence);
			if(residence !=null) {
				residenceService.delete(idResidence);
			}
		}
		return"redirect:/residence/";
	}
}
