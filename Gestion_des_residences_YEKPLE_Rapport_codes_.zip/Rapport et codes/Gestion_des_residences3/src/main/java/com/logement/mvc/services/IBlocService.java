package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Bloc;



public interface IBlocService {

    public Bloc save(Bloc entity);
	public Bloc update(Bloc entity);
	public List<Bloc> selectAll();
	//Selectionner toutes les enregistrements en faisant le tri
	public List<Bloc> selectAll(String sortField, String sort);
	public Bloc getById(Long id);
	public void delete(Long id);
	// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
	public Bloc findOne(String paramName, Object paramValue);
	public Bloc findOne(String[] paramNames, Object[] paramValues);
}
