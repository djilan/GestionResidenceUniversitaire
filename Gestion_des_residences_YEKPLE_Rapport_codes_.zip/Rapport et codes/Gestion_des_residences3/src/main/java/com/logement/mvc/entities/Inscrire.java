package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="INSCRIPTION")
public class Inscrire implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="CODE_INSCRIPTION")
	private Long idInscription;
    
    private String codeInscrire;
    
    @Column(name="DATE_INSCRIPTION")
    @DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateInscription;
    
    @ManyToOne
	@JoinColumn(name="code_etudiant")
    private Etudiant etudiants;
    
    @ManyToOne
	@JoinColumn(name="id_residence")
    private Residence residences;
    
	
	public Long getIdInscription() {
		return idInscription;
	}
	public void setIdInscription(Long idInscription) {
		this.idInscription = idInscription;
	}
	public String getCodeInscrire() {
		return codeInscrire;
	}
	public void setCodeInscrire(String codeInscrire) {
		this.codeInscrire = codeInscrire;
	}
	public Date getDateInscription() {
		return dateInscription;
	}
	public void setDateInscription(Date dateInscription) {
		this.dateInscription = dateInscription;
	}
	public Etudiant getEtudiants() {
		return etudiants;
	}
	public void setEtudiants(Etudiant etudiants) {
		this.etudiants = etudiants;
	}
	public Residence getResidences() {
		return residences;
	}
	public void setResidences(Residence residences) {
		this.residences = residences;
	}
	public Inscrire() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
