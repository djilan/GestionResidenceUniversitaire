package com.logement.mvc.dao;

import com.logement.mvc.entities.Demande;
/*Interface*/
public interface IDemandeDao extends IGenericDao<Demande> {

}
