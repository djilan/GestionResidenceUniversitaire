package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IOperationsDao;
import com.logement.mvc.entities.Operations;

public class OperationDaoImpl extends GenericDaoImpl<Operations> implements IOperationsDao {

}
