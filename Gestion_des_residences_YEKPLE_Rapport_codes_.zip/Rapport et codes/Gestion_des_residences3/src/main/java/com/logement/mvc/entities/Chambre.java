package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="CHAMBRES")
public class Chambre implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="Code_Chambre")
	private Long idChambre;
	
	private String chambreCode;
	@Column(name="CAPACITE_CHAMBRE")
	private Integer capaciteChambre;
	
	@Column(name="NOMBRE_PLACES_LIBRES")
	private Integer nbrePlaceslibres;
	
	@Column(name="PRIX_CHAMBRE")
	private Integer prixChambre;
	
	@Column(name="CATEGORIE_CHAMBRE")
	private String categorieChambre;
	
	
	@ManyToOne
	@JoinColumn(name="id_bloc")
	private Bloc blocs;
	
    @OneToMany(mappedBy="chambres")
	private List<Affecter> affecters;
	
	
	public Long getIdChambre() {
		return idChambre;
	}
	public void setIdChambre(Long idChambre) {
		this.idChambre = idChambre;
	}
	public String getChambreCode() {
		return chambreCode;
	}
	public void setChambreCode(String chambreCode) {
		this.chambreCode = chambreCode;
	}
	public Integer getCapaciteChambre() {
		return capaciteChambre;
	}
	public void setCapaciteChambre(Integer capaciteChambre) {
		this.capaciteChambre = capaciteChambre;
	}
	public Integer getNbrePlaceslibres() {
		return nbrePlaceslibres;
	}
	public void setNbrePlaceslibres(Integer nbrePlaceslibres) {
		this.nbrePlaceslibres = nbrePlaceslibres;
	}
	public Integer getPrixChambre() {
		return prixChambre;
	}
	public void setPrixChambre(Integer prixChambre) {
		this.prixChambre = prixChambre;
	}
	public String getCategorieChambre() {
		return categorieChambre;
	}
	public void setCategorieChambre(String categorieChambre) {
		this.categorieChambre = categorieChambre;
	}
	public Bloc getBlocs() {
		return blocs;
	}
	public void setBlocs(Bloc blocs) {
		this.blocs = blocs;
	}
	
	public List<Affecter> getAffecters() {
		return affecters;
	}
	public void setAffecters(List<Affecter> affecters) {
		this.affecters = affecters;
	}
	public Chambre() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
