package com.logement.mvc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.logement.mvc.entities.Affecter;
import com.logement.mvc.entities.Chambre;
import com.logement.mvc.entities.Etudiant;
import com.logement.mvc.services.IAffecterService;
import com.logement.mvc.services.IChambreService;
import com.logement.mvc.services.IEtudiantService;

@Controller
@RequestMapping(value="/affecter")
public class AffecterController {

	@Autowired
	private IAffecterService affecterService;
	@Autowired
	private IChambreService chambreService;
	@Autowired
	private IEtudiantService etudiantService;
	@RequestMapping(value="/")
	public String affecter(Map<String , Object >map) {
		
	
		Affecter affecter=new Affecter();
		map.put("affecter", affecter);
		map.put("affecterList", affecterService.selectAll());
		return"affecter/affecter";
	}
	
	@RequestMapping(value="/nouvelle", method=RequestMethod.GET)
	public String addAffecter(Model model) {
		
		Affecter affecter=new Affecter();
		List<Chambre>chambres=chambreService.selectAll();
		if(chambres ==null) {
			chambres=new ArrayList<Chambre>();
		}
		List<Etudiant> etudiants=etudiantService.selectAll();
		if(etudiants ==null) {
			etudiants=new ArrayList<Etudiant>();
		}
		model.addAttribute("affecter", affecter);
		model.addAttribute("chambres", chambres);
		model.addAttribute("etudiants", etudiants);
		return "affecter/AddAffecter";
		
	}
	@RequestMapping(value="/nouvelle", method=RequestMethod.POST)
	public String enregistrerAffecter(Affecter affecter) {
		if(affecter.getIdAffectation() !=null) {
			affecterService.update(affecter);
		}else {
			affecterService.save(affecter);
		}
		return"redirect:/affecter/";
	}
	@RequestMapping(value="/modifier/{idAffectation}")
	public String modifierAffecter(Model model, @PathVariable Long idAffectation) {
		if(idAffectation !=null) {
			
			Affecter affecter=affecterService.getById(idAffectation);
			List<Chambre>chambres=chambreService.selectAll();
			if(chambres ==null) {
				chambres=new ArrayList<Chambre>();
			}
			model.addAttribute("chambres", chambres);
			List<Etudiant> etudiants=etudiantService.selectAll();
			if(etudiants ==null) {
				etudiants=new ArrayList<Etudiant>();
			}
			model.addAttribute("etudiants", etudiants);
			if(affecter !=null) {
				model.addAttribute("affecter", affecter);
			}
		}
		return "affecter/AddAffecter";
	}
	
	@RequestMapping(value="/supprimer/{idAffectation}")
	public String supprimerAffecter(Model model, @PathVariable Long idAffectation) {
		if(idAffectation !=null) {
			Affecter affecter=affecterService.getById(idAffectation);
			if(affecter !=null) {
				affecterService.delete(idAffectation);
			}
		}
		return"redirect:/affecter/";
	}
}
