package com.logement.mvc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.logement.mvc.entities.Bloc;
import com.logement.mvc.entities.Chambre;
import com.logement.mvc.services.IBlocService;
import com.logement.mvc.services.IChambreService;

@Controller
@RequestMapping(value="/chambre")
public class ChambreController {
     @Autowired
	private IChambreService chambreService;
     @Autowired
     private IBlocService blocService;
 	@RequestMapping(value="/")
     public String chambre(Map<String , Object >map) {
    	 Chambre chambres=new Chambre();
    	 map.put("chambres", chambres);
    	 map.put("chambresList", chambreService.selectAll());
    	 return"chambre/chambre";
     }
     @RequestMapping(value="/nouvelle", method=RequestMethod.GET)
     public String addChambre(Model model) {
    	 Chambre chambre=new Chambre();
    	 List<Bloc>blocs=blocService.selectAll();
    	 if(blocs ==null) {
    		 blocs=new ArrayList<Bloc>();
    	 }
    	 model.addAttribute("chambre", chambre);
    	 model.addAttribute("blocs", blocs);
    	 return "chambre/AddChambre";
     }
     @RequestMapping(value="/nouvelle", method=RequestMethod.POST)
     public String enregistrerChambre(Chambre chambre) {
    	 if(chambre.getIdChambre()  !=null) {
    		 chambreService.update(chambre);
    	 }else {
    		 chambreService.save(chambre);
    	 }
    	 return "redirect:/chambre/";
     }
     @RequestMapping(value="/modifier/{idChambre}")
     public String modifierChambre(Model model, @PathVariable Long idChambre) {
    	 if(idChambre !=null) {
    		 Chambre chambre=chambreService.getById(idChambre);
    		 List<Bloc>blocs=blocService.selectAll();
        	 if(blocs ==null) {
        		 blocs=new ArrayList<Bloc>();
        	 }
        	 model.addAttribute("blocs", blocs);
    		 if(chambre !=null) {
    			 model.addAttribute("chambre", chambre);
    		 }
    	 }
    	 return "chambre/AddChambre";
     }
     @RequestMapping(value="/supprimer/{idChambre}")
     public String supprimerChambre(Model model, @PathVariable Long idChambre) {
    	 if(idChambre !=null) {
    		 Chambre chambre=chambreService.getById(idChambre);
    		 if(chambre !=null) {
    			 chambreService.delete(idChambre);
    		 }
    	 }
    	 return "redirect:/chambre/";
     }
}
