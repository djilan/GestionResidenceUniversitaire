package com.logement.mvc.dao;

import com.logement.mvc.entities.Affecter;
/*Interface*/
public interface IAffecterDao extends IGenericDao<Affecter> {

}
