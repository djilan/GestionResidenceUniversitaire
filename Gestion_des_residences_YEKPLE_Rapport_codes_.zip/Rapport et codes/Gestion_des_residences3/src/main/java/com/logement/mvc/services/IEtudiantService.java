package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Etudiant;

public interface IEtudiantService {

    public Etudiant save(Etudiant entity);
	public Etudiant update(Etudiant entity);
	public List<Etudiant> selectAll();
	//Selectionner toutes les enregistrements en faisant le tri
	public List<Etudiant> selectAll(String sortField, String sort);
	public Etudiant getById(Long id);
	public void delete(Long id);
	// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
	public Etudiant findOne(String paramName, Object paramValue);
	public Etudiant findOne(String[] paramNames, Object[] paramValues);
}
