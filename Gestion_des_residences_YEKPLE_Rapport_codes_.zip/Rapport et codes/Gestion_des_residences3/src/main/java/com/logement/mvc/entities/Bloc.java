package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="BLOCS")
public class Bloc implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CODE_BLOC")
	private Long idBloc;
	private String blocCode;
	@Column(name="NOM_BLOC")
	private String nomBloc;
	@Column(name="NOMBRE_CHAMBRES")
	private Integer nbreChambre;
	@ManyToOne
    @JoinColumn(name="id_residence")
	private Residence residences;
	@OneToMany(mappedBy="blocs")
	private List<Chambre> chambres;
	
	
	
	
	public Long getIdBloc() {
		return idBloc;
	}
	public void setIdBloc(Long idBloc) {
		this.idBloc = idBloc;
	}
	public String getBlocCode() {
		return blocCode;
	}
	public void setBlocCode(String blocCode) {
		this.blocCode = blocCode;
	}
	public String getNomBloc() {
		return nomBloc;
	}
	public void setNomBloc(String nomBloc) {
		this.nomBloc = nomBloc;
	}
	public Integer getNbreChambre() {
		return nbreChambre;
	}
	public void setNbreChambre(Integer nbreChambre) {
		this.nbreChambre = nbreChambre;
	}
	public Residence getResidences() {
		return residences;
	}
	public void setResidences(Residence residences) {
		this.residences = residences;
	}
	public List<Chambre> getChambres() {
		return chambres;
	}
	public void setChambres(List<Chambre> chambres) {
		this.chambres = chambres;
	}
	public Bloc() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
