package com.logement.mvc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.logement.mvc.entities.Demande;
import com.logement.mvc.entities.Residence;
import com.logement.mvc.services.IDemandeService;
import com.logement.mvc.services.IResidenceService;
@Controller
@RequestMapping(value="/demande")
public class DemandeController {

	@Autowired
    private IDemandeService demandeService;

	@Autowired
	private IResidenceService residenceService;
	
	@RequestMapping(value="/")
    public String demande(Map<String , Object >map) {
   	 Demande demandes=new Demande();
   	 map.put("demandes", demandes);
   	 map.put("demandesList", demandeService.selectAll());
   	 return"demande/demande";
    }
	 @RequestMapping(value="/nouvelle", method=RequestMethod.GET)
     public String addDemande(Model model) {
    	 Demande demandes=new Demande();
    	 List<Residence>residences=residenceService.selectAll();
    	 if(residences ==null) {
    		 residences=new ArrayList<Residence>();
    	 }
    	 model.addAttribute("demandes", demandes);
    	 model.addAttribute("residences", residences);
/*    	 return "demande/AddDemande";
*/    
    	 return "demande/AddDemande";
	 }
	 @RequestMapping(value="/nouvelle", method=RequestMethod.POST)
     public String enregistrerDemande(Demande demande) {
    	 if(demande.getIdDemande()!=null) {
    		 demandeService.update(demande);
    	 }else {
    		 demandeService.save(demande);
    		 sendEmail(demande);
    	 }
    	 return "redirect:/demande/nouvelle/";
     }
	 
	 
	 
		public void sendEmail(Demande demande) {
			final String emailFrom = "sissokoben02@gmail.com";
			final String password = "Ben123456789";
			String emailTo = demande.getEmail();
			System.out.println("*************************DEMANDE DE CHAMBRE*************************");
			String sujet = "Votre demande de chambre est No: " + String.valueOf(demande.getIdDemande()+ ""+
					" "+String.valueOf(demande.getNom())+ ""+"" +String.valueOf(demande.getPrenom()
							+ " "+String.valueOf(demande.getDateNaiss())+ " " +String.valueOf(demande.getResidence().getResidenceCode())
							+ " "+String.valueOf(demande.getUniversite())));
			StringBuilder stringBuilder = new StringBuilder();
/*			stringBuilder.append("Demande effectuee " + demande.getNom()+"\nNom:..........."+demande.getNom());
*/
			stringBuilder.append("Demande effectuee " + "\nNom:..........."+demande.getNom()
			+"\nPrenom:............"+demande.getPrenom()+"\nDate demande:......."+demande.getDateNaiss()
			+"\nResidence:..........."+demande.getResidence().getResidenceCode()+"\nUniversite:..........."+demande.getUniversite());
			String message = stringBuilder.toString();
			System.out.println("Message == " + message);

			Properties props = new Properties();

			props.put("mail.transport.protocol", "smtp");
			props.put("mail.debug", "true");
			props.put("mail.smtp.starttls.enable", "true");
			props.put("mail.smtp.socketFactory.port", "465");
			props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
			props.put("mail.smtp.auth", "true");
			props.put("mail.smtp.host", "smtp.gmail.com");
			props.put("mail.smtp.port", "465");
			props.put("mail.smtp.timeout", "10000");
			props.put("mail.smtp.ssl.checkserveridentity", "false");
			props.put("mail.smtp.ssl.trust", "*");
			props.put("mail.smtp.connectiontimeout", "10000");
			props.put("mail.smtp.debug", "true");
			props.put("mail.smtp.socketFactory.fallback", "false");

			Session session = Session.getInstance(props, new javax.mail.Authenticator() {
				protected PasswordAuthentication getPasswordAuthentication() {
					return new PasswordAuthentication(emailFrom, password);
				}

			});

			try {
				Message mailMessage = new MimeMessage(session);
				mailMessage.setFrom(new InternetAddress(emailFrom));
				mailMessage.setRecipients(Message.RecipientType.TO, InternetAddress.parse(emailTo));

				mailMessage.setSubject(sujet);
				mailMessage.setText(message);
				Transport.send(mailMessage);
				System.out.println("Email envoye avec succes");
			} catch (MessagingException e) {
				System.out.println("Unable to send mail" + e.getMessage());
				throw new RuntimeException(e);
			}
		}

}
