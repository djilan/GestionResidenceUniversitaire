package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IUtilisateurDao;
import com.logement.mvc.entities.Utilisateur;

public class UtilisateurDaoImpl extends GenericDaoImpl<Utilisateur> implements IUtilisateurDao{

}
