package com.logement.mvc.dao;

import com.logement.mvc.entities.Bloc;
/*Interface*/
public interface IBlocDao extends IGenericDao<Bloc> {

}
