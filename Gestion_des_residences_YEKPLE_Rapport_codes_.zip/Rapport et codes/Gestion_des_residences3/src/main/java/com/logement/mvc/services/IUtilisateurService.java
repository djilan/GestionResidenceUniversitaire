package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Utilisateur;

public interface IUtilisateurService {

	    public Utilisateur save(Utilisateur entity);
		public Utilisateur update(Utilisateur entity);
		public List<Utilisateur> selectAll();
		//Selectionner toutes les enregistrements en faisant le tri
		public List<Utilisateur> selectAll(String sortField, String sort);
		public Utilisateur getById(Long id);
		public void delete(Long id);
		// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
		public Utilisateur findOne(String paramName, Object paramValue);
		public Utilisateur findOne(String[] paramNames, Object[] paramValues);
}
