package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IChambreDao;
import com.logement.mvc.entities.Chambre;

public class ChambreDaoImpl extends GenericDaoImpl<Chambre> implements IChambreDao{

}
