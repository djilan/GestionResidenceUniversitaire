package com.logement.mvc.dao;

import com.logement.mvc.entities.Utilisateur;
/*Interface*/
public interface IUtilisateurDao extends IGenericDao<Utilisateur>{

}
