package com.logement.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.logement.mvc.dao.IInscrireDao;
import com.logement.mvc.entities.Inscrire;
import com.logement.mvc.services.IInscrireService;
@Transactional
public class InscrireServiceImpl  implements IInscrireService{
    
	private IInscrireDao dao;
	
	public void setDao(IInscrireDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Inscrire save(Inscrire entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Inscrire update(Inscrire entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public List<Inscrire> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Inscrire> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return dao.selectAll(sortField, sort);
	}

	@Override
	public Inscrire getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Inscrire findOne(String paramName, Object paramValue) {
		// TODO Auto-generated method stub
		return dao.findOne(paramName, paramValue);
	}

	@Override
	public Inscrire findOne(String[] paramNames, Object[] paramValues) {
		// TODO Auto-generated method stub
		return dao.findOne(paramNames, paramValues);
	}

}
