package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IInscrireDao;
import com.logement.mvc.entities.Inscrire;

public class InscrireDaoImpl extends GenericDaoImpl<Inscrire> implements IInscrireDao{

}
