package com.logement.mvc.controllers;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.logement.mvc.entities.Etudiant;
import com.logement.mvc.export.FileExporter;
import com.logement.mvc.services.IEtudiantService;

@Controller
@RequestMapping(value="/etudiant")
public class EtudiantController {

	@Autowired
	private IEtudiantService  etudiantService;

	@Autowired
	@Qualifier("etudiantExporter")
	private FileExporter exporter;
	
	@RequestMapping(value="/")
	public String etudiant(Map<String , Object >map) {
	Etudiant etudiants =new Etudiant();
	map.put("etudiants", etudiants);
	map.put("etudiantsList", etudiantService.selectAll());
	return"etudiant/etudiant";
	}
	@RequestMapping(value="/nouveau", method=RequestMethod.GET)
	public String addEtudiant(Model model) {
		Etudiant etudiant=new Etudiant();
		model.addAttribute("etudiant", etudiant);
		return"etudiant/AddEtudiant";
	}
	@RequestMapping(value="/nouveau", method=RequestMethod.POST)
	public String enregistrerEtudiant(Etudiant etudiant) {
		
		if(etudiant.getCodeEtudiant() !=null) {
			etudiantService.update(etudiant);
		}else {
			etudiantService.save(etudiant);
		}
		
    
		return"redirect:/etudiant/";
	}
	@RequestMapping(value="/modifier/{codeEtudiant}")
	public String modifierEtudiant(Model model, @PathVariable Long codeEtudiant) {
		
		if(codeEtudiant !=null) {
			Etudiant etudiant=etudiantService.getById(codeEtudiant);
			if(etudiant !=null) {
				model.addAttribute("etudiant", etudiant);
			}
		}
		return "etudiant/AddEtudiant";
	}
	@RequestMapping(value="/supprimer/{codeEtudiant}")
	public String supprimerEtudiant(Model model, @PathVariable Long codeEtudiant) {
		if(codeEtudiant !=null) {
			Etudiant etudiant=etudiantService.getById(codeEtudiant);
			if(etudiant !=null) {
				etudiantService.delete(codeEtudiant);
			}
		}
		return"redirect:/etudiant/";
	}
	
	@RequestMapping(value = "/export/")
	public String exporterEtudiant(HttpServletResponse response) {
		exporter.exportDataToExcel(response, null, null);
		return "etudiant/etudiant";
	}
	
}
