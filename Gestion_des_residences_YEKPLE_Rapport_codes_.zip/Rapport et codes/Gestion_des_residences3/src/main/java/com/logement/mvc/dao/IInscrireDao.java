package com.logement.mvc.dao;

import com.logement.mvc.entities.Inscrire;
/*Interface*/
public interface IInscrireDao extends IGenericDao<Inscrire>{

}
