package com.logement.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.logement.mvc.dao.IOperationsDao;
import com.logement.mvc.entities.Operations;
import com.logement.mvc.services.IOperationsService;
@Transactional
public class OperationsServiceImpl  implements IOperationsService{
    
	private IOperationsDao dao;
	
	public void setDao(IOperationsDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Operations save(Operations entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Operations update(Operations entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public List<Operations> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Operations> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return dao.selectAll(sortField, sort);
	}

	@Override
	public Operations getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Operations findOne(String paramName, Object paramValue) {
		// TODO Auto-generated method stub
		return dao.findOne(paramName, paramValue);
	}

	@Override
	public Operations findOne(String[] paramNames, Object[] paramValues) {
		// TODO Auto-generated method stub
		return dao.findOne(paramNames, paramValues);
	}

}
