package com.logement.mvc.dao;

import com.logement.mvc.entities.Etudiant;
/*Interface*/
public interface IEtudiantDao extends IGenericDao<Etudiant> {

}
