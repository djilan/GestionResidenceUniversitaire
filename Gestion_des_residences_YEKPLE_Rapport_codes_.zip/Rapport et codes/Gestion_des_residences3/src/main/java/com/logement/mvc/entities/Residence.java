package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="RESIDENCES")
public class Residence implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	@Column(name="CODE_RESIDENCE")
	private Long idResidence;
	
	private String residenceCode;
	@Column(name="NOM_RESIDENCE")
	private String nomResidence;
	@Column(name="ADRESSE_RESIDENCE")
	private String addresseResidence;
	@Column(name="CAPACITE")
	private Integer capaciteResidence;
	@Column(name="NOM_DIRECTEUR")
	private String nomDirecteur;
	@Column(name="PRENOM_DIRECTEUR")
	private String prenomDirecteur;
	
	@OneToMany(mappedBy="residences")
	private List<Bloc> blocs;
	
	@OneToMany(mappedBy="residences")
	private List<Inscrire> inscrires;
	@OneToMany(mappedBy="residence")
	private List<Demande>demandes;
	
	
	
	public Long getIdResidence() {
		return idResidence;
	}
	public void setIdResidence(Long idResidence) {
		this.idResidence = idResidence;
	}
	
	public String getResidenceCode() {
		return residenceCode;
	}
	public void setResidenceCode(String residenceCode) {
		this.residenceCode = residenceCode;
	}
	public String getNomResidence() {
		return nomResidence;
	}
	public void setNomResidence(String nomResidence) {
		this.nomResidence = nomResidence;
	}
	public String getAddresseResidence() {
		return addresseResidence;
	}
	public void setAddresseResidence(String addresseResidence) {
		this.addresseResidence = addresseResidence;
	}
	public Integer getCapaciteResidence() {
		return capaciteResidence;
	}
	public void setCapaciteResidence(Integer capaciteResidence) {
		this.capaciteResidence = capaciteResidence;
	}
	public String getNomDirecteur() {
		return nomDirecteur;
	}
	public void setNomDirecteur(String nomDirecteur) {
		this.nomDirecteur = nomDirecteur;
	}
	public String getPrenomDirecteur() {
		return prenomDirecteur;
	}
	public void setPrenomDirecteur(String prenomDirecteur) {
		this.prenomDirecteur = prenomDirecteur;
	}
	public List<Bloc> getBlocs() {
		return blocs;
	}
	public void setBlocs(List<Bloc> blocs) {
		this.blocs = blocs;
	}
	public List<Inscrire> getInscrires() {
		return inscrires;
	}
	public void setInscrires(List<Inscrire> inscrires) {
		this.inscrires = inscrires;
	}
	
	public List<Demande> getDemandes() {
		return demandes;
	}
	public void setDemandes(List<Demande> demandes) {
		this.demandes = demandes;
	}
	public Residence() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
