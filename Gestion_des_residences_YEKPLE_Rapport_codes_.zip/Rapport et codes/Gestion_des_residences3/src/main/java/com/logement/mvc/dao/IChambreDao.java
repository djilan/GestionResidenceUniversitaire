package com.logement.mvc.dao;

import com.logement.mvc.entities.Chambre;
/*Interface*/
public interface IChambreDao extends IGenericDao<Chambre>{

}
