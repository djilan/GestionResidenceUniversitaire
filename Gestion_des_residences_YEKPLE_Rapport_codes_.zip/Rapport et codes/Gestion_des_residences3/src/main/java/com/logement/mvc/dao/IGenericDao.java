package com.logement.mvc.dao;

import java.util.List;
/*Interface*/
public interface IGenericDao<E> {

	public E save(E entity);
	
	public E update(E entity);
	
	public List<E> selectAll();
	
	//Selectionner toutes les enregistrements en faisant le tri
	public List<E> selectAll(String sortField, String sort);
	
	public E getById(Long id);
	
	public void delete(Long id);
	
	// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
	
	public E findOne(String paramName, Object paramValue);
	
	public E findOne(String[] paramNames, Object[] paramValues);
	
}
