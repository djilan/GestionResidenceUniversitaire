package com.logement.mvc.dao;

import com.logement.mvc.entities.Residence;
/*Interface*/
public interface IResidenceDao extends IGenericDao<Residence> {

}
