package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Residence;

public interface IResidenceService {

	    public Residence save(Residence entity);
		public Residence update(Residence entity);
		public List<Residence> selectAll();
		//Selectionner toutes les enregistrements en faisant le tri
		public List<Residence> selectAll(String sortField, String sort);
		public Residence getById(Long id);
		public void delete(Long id);
		// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
		public Residence findOne(String paramName, Object paramValue);
		public Residence findOne(String[] paramNames, Object[] paramValues);
	
}
