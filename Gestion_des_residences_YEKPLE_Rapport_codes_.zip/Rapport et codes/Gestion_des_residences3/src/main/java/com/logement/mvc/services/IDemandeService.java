package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Demande;

public interface IDemandeService {
	public Demande save(Demande entity);
	public Demande update(Demande entity);
	public List<Demande> selectAll();
	//Selectionner toutes les enregistrements en faisant le tri
	public List<Demande> selectAll(String sortField, String sort);
	public Demande getById(Long id);
	public void delete(Long id);
	// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
	public Demande findOne(String paramName, Object paramValue);
	public Demande findOne(String[] paramNames, Object[] paramValues);
}
