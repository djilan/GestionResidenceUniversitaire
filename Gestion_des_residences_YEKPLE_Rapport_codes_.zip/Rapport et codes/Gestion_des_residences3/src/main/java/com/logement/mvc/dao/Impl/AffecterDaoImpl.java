package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IAffecterDao;
import com.logement.mvc.entities.Affecter;

public class AffecterDaoImpl extends GenericDaoImpl<Affecter> implements IAffecterDao{

}
