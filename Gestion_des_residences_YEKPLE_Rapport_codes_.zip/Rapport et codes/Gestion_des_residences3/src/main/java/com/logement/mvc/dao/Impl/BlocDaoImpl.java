package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IBlocDao;
import com.logement.mvc.entities.Bloc;

public class BlocDaoImpl extends GenericDaoImpl<Bloc> implements IBlocDao {

}
