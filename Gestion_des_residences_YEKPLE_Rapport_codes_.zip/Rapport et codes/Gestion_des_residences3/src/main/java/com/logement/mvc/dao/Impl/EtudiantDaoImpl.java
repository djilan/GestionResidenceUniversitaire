package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IEtudiantDao;
import com.logement.mvc.entities.Etudiant;

public class EtudiantDaoImpl extends GenericDaoImpl<Etudiant> implements IEtudiantDao {

}
