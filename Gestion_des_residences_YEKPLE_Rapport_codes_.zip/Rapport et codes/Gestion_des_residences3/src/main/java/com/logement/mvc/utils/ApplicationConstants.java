package com.logement.mvc.utils;

public class ApplicationConstants {

	private ApplicationConstants() {}
		
	public static final String EXCEL_CONTENT_TYPE="application/vnd.ms-excel";
	public static final String CONTENT_DISPOSITION = "Content-disposition";
	public static final String DEFAULT_ENCODAGE = "ISO-8859-1";
	public static final String CODE_ETUDIANT = "MATRICULE";
	public static final String NOM = "NOM ETUDIANT";
	public static final String PRENON = "PRENOM ETUDIANT";
	public static final String Sexe = "SEXE";
	public static final String DateNaissance = "DATE NAISSANCE";
	public static final String Lieu = "LIEU";
	public static final String Adresse = "ADRESSE";
	public static final String Nationalite = "NATIONALITE";
	public static final String Universite = "UNIVERSITE";
	public static final String Filiere = "FILIERE";
	public static final String Email = "@Email";
}
