package com.logement.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.logement.mvc.dao.IAffecterDao;
import com.logement.mvc.entities.Affecter;
import com.logement.mvc.services.IAffecterService;
@Transactional
public class AffecterServiceImpl implements IAffecterService{
     
	private IAffecterDao dao;
	
	public void setDao(IAffecterDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Affecter save(Affecter entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Affecter update(Affecter entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public List<Affecter> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Affecter> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return dao.selectAll(sortField, sort);
	}

	@Override
	public Affecter getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Affecter findOne(String paramName, Object paramValue) {
		// TODO Auto-generated method stub
		return dao.findOne(paramName, paramValue);
	}

	@Override
	public Affecter findOne(String[] paramNames, Object[] paramValues) {
		// TODO Auto-generated method stub
		return dao.findOne(paramNames, paramValues);
	}

}
