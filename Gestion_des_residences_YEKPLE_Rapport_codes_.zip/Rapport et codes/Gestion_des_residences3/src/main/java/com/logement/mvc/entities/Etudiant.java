package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="ETUDIANT")
public class Etudiant implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private Long codeEtudiant;
    private String matricule;
	private String nom;
	private String prenom;
	private String sexe;
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date  date;
	private String lieuNaissance;
	private String adresse;
	private String nationalite;
	private String universite;
	private String filiere;
	private String email;
//	private String status;
	
	@OneToMany(mappedBy="etudiant")
	private List<Operations> operation;
	
	@OneToMany(mappedBy="etudiants")
	private List<Affecter> affecter;
	
	@OneToMany(mappedBy="etudiants")
	private List<Inscrire> inscrire;

	public Long getCodeEtudiant() {
		return codeEtudiant;
	}

	public void setCodeEtudiant(Long codeEtudiant) {
		this.codeEtudiant = codeEtudiant;
	}

	public String getMatricule() {
		return matricule;
	}

	public void setMatricule(String matricule) {
		this.matricule = matricule;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getPrenom() {
		return prenom;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public String getSexe() {
		return sexe;
	}

	public void setSexe(String sexe) {
		this.sexe = sexe;
	}

	

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public String getLieuNaissance() {
		return lieuNaissance;
	}

	public void setLieuNaissance(String lieuNaissance) {
		this.lieuNaissance = lieuNaissance;
	}

	public String getAdresse() {
		return adresse;
	}

	public void setAdresse(String adresse) {
		this.adresse = adresse;
	}

	public String getNationalite() {
		return nationalite;
	}

	public void setNationalite(String nationalite) {
		this.nationalite = nationalite;
	}

	public String getUniversite() {
		return universite;
	}

	public void setUniversite(String universite) {
		this.universite = universite;
	}

	public String getFiliere() {
		return filiere;
	}

	public void setFiliere(String filiere) {
		this.filiere = filiere;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<Operations> getOperation() {
		return operation;
	}

	public void setOperation(List<Operations> operation) {
		this.operation = operation;
	}

	public List<Affecter> getAffecter() {
		return affecter;
	}

	public void setAffecter(List<Affecter> affecter) {
		this.affecter = affecter;
	}

	public List<Inscrire> getInscrire() {
		return inscrire;
	}

	public void setInscrire(List<Inscrire> inscrire) {
		this.inscrire = inscrire;
	}

	public Etudiant() {
		super();
		// TODO Auto-generated constructor stub
	}

	
}
