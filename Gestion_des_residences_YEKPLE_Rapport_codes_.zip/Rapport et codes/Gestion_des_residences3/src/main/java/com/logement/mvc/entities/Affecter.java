package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;
@Entity
@Table(name="AFFECTATION")
public class Affecter implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy=GenerationType.IDENTITY)
    @Column(name="CODE_AFFECTATION")
	private Long idAffectation;
    
    private String codeAffecter;
  
    @DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateAffectation;
    
    @ManyToOne
	@JoinColumn(name="code_etudiant")
    private Etudiant etudiants;
    
    @ManyToOne
	@JoinColumn(name="id_chambre")
    private Chambre chambres;
   
	public Long getIdAffectation() {
		return idAffectation;
	}
	public void setIdAffectation(Long idAffectation) {
		this.idAffectation = idAffectation;
	}
	public String getCodeAffecter() {
		return codeAffecter;
	}
	public void setCodeAffecter(String codeAffecter) {
		this.codeAffecter = codeAffecter;
	}
	public Date getDateAffectation() {
		return dateAffectation;
	}
	public void setDateAffectation(Date dateAffectation) {
		this.dateAffectation = dateAffectation;
	}
	public Etudiant getEtudiants() {
		return etudiants;
	}
	public void setEtudiants(Etudiant etudiants) {
		this.etudiants = etudiants;
	}
	public Chambre getChambres() {
		return chambres;
	}
	public void setChambres(Chambre chambres) {
		this.chambres = chambres;
	}
	
	public Affecter() {
		super();
		// TODO Auto-generated constructor stub
	}
	
}
