package com.logement.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.logement.mvc.dao.IBlocDao;
import com.logement.mvc.entities.Bloc;
import com.logement.mvc.services.IBlocService;
@Transactional
public class BlocServiceImpl implements IBlocService {

	private IBlocDao dao;
	
	public void setDao(IBlocDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Bloc save(Bloc entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Bloc update(Bloc entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public List<Bloc> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Bloc> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return dao.selectAll(sortField, sort);
	}

	@Override
	public Bloc getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Bloc findOne(String paramName, Object paramValue) {
		// TODO Auto-generated method stub
		return dao.findOne(paramName, paramValue);
	}

	@Override
	public Bloc findOne(String[] paramNames, Object[] paramValues) {
		// TODO Auto-generated method stub
		return dao.findOne(paramNames, paramValues);
	}

}
