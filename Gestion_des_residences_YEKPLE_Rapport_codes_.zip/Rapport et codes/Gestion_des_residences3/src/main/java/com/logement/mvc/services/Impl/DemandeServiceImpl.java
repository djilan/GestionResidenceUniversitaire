package com.logement.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.logement.mvc.dao.IDemandeDao;
import com.logement.mvc.entities.Demande;
import com.logement.mvc.services.IDemandeService;
@Transactional
public class DemandeServiceImpl implements IDemandeService {

	private IDemandeDao dao;
	
	public void setDao(IDemandeDao dao) {
		this.dao = dao;
	}

	@Override
	public Demande save(Demande entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Demande update(Demande entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public List<Demande> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Demande> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return dao.selectAll(sortField, sort);
	}

	@Override
	public Demande getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Demande findOne(String paramName, Object paramValue) {
		// TODO Auto-generated method stub
		return dao.findOne(paramName, paramValue);
	}

	@Override
	public Demande findOne(String[] paramNames, Object[] paramValues) {
		// TODO Auto-generated method stub
		return dao.findOne(paramNames, paramValues);
	}

	
}
