package com.logement.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.logement.mvc.dao.IChambreDao;
import com.logement.mvc.entities.Chambre;
import com.logement.mvc.services.IChambreService;
@Transactional
public class ChambreServiceImpl implements IChambreService {
 
	private IChambreDao dao;
	
	public void setDao(IChambreDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Chambre save(Chambre entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Chambre update(Chambre entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public List<Chambre> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Chambre> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return dao.selectAll(sortField, sort);
	}

	@Override
	public Chambre getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Chambre findOne(String paramName, Object paramValue) {
		// TODO Auto-generated method stub
		return dao.findOne(paramName, paramValue);
	}

	@Override
	public Chambre findOne(String[] paramNames, Object[] paramValues) {
		// TODO Auto-generated method stub
		return dao.findOne(paramNames, paramValues);
	}

}
