package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IResidenceDao;
import com.logement.mvc.entities.Residence;

public class ResidenceDaoImpl extends GenericDaoImpl<Residence> implements IResidenceDao{

}
