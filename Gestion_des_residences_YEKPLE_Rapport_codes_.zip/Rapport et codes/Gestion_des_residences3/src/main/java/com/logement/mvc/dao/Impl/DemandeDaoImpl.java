package com.logement.mvc.dao.Impl;

import com.logement.mvc.dao.IDemandeDao;
import com.logement.mvc.entities.Demande;

public class DemandeDaoImpl extends GenericDaoImpl<Demande> implements IDemandeDao{

}
