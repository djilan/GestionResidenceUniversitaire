package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Operations;



public interface IOperationsService {

	
	    public Operations save(Operations entity);
		public Operations update(Operations entity);
		public List<Operations> selectAll();
		//Selectionner toutes les enregistrements en faisant le tri
		public List<Operations> selectAll(String sortField, String sort);
		public Operations getById(Long id);
		public void delete(Long id);
		// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
		public Operations findOne(String paramName, Object paramValue);
		public Operations findOne(String[] paramNames, Object[] paramValues);
}
