package com.logement.mvc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.logement.mvc.entities.Bloc;
import com.logement.mvc.entities.Residence;
import com.logement.mvc.services.IBlocService;
import com.logement.mvc.services.IResidenceService;

@Controller
@RequestMapping(value="/bloc")
public class BlocController {

	@Autowired
	private IBlocService blocService;
	
	@Autowired
	private IResidenceService residenceService;
	
	@RequestMapping(value="/")
	public String bloc(Map<String , Object >map) {
		Bloc blocs=new Bloc();
		map.put("blocs", blocs);
		map.put("blocsList", blocService.selectAll());
		return "bloc/bloc";
	}
	@RequestMapping(value="/nouveau", method=RequestMethod.GET)
	public String addBloc(Model model) {
		Bloc bloc=new Bloc();
		List<Residence> residences=residenceService.selectAll();
		if(residences ==null) {
			residences=new ArrayList<Residence>();
		}
		model.addAttribute("bloc", bloc);
		model.addAttribute("residences", residences);
		return "bloc/AddBloc";
	}
	@RequestMapping(value="/nouveau", method=RequestMethod.POST)
	public String enregistrerBloc(Bloc bloc) {
		if(bloc.getIdBloc() !=null) {
			blocService.update(bloc);
		}else {
			blocService.save(bloc);
		}
		return"redirect:/bloc/";
	}
	@RequestMapping(value="/modifier/{idBloc}")
	public String modifierBloc(Model model, @PathVariable Long idBloc) {
		if(idBloc !=null) {
			Bloc bloc=blocService.getById(idBloc);
			List<Residence> residences=residenceService.selectAll();
			if(residences ==null) {
				residences=new ArrayList<Residence>();
			}
			model.addAttribute("residences", residences);
			if(bloc !=null) {
				model.addAttribute("bloc", bloc);
			}
		}
		return"bloc/AddBloc";
	}
	@RequestMapping(value="/supprimer/{idBloc}")
	public String supprimerBloc(Model model, @PathVariable Long idBloc) {
		if(idBloc !=null) {
			Bloc bloc=blocService.getById(idBloc);
			if(bloc !=null) {
				blocService.delete(idBloc);
			}
		}
		return"redirect:/bloc/";
	}
}
