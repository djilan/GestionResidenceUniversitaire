package com.logement.mvc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.logement.mvc.entities.Etudiant;
import com.logement.mvc.entities.Inscrire;
import com.logement.mvc.entities.Residence;
import com.logement.mvc.services.IEtudiantService;
import com.logement.mvc.services.IInscrireService;
import com.logement.mvc.services.IResidenceService;


@Controller
@RequestMapping(value="/inscrire ")
public class InscrireController {

	@Autowired
	private IInscrireService inscrireService;
	@Autowired
	private IEtudiantService etudiantService;
	@Autowired
	private IResidenceService residenceService;
	@RequestMapping(value="/")
	public String inscrire(Map<String , Object >map) {
		
	Inscrire inscrire=new Inscrire();
    map.put("inscrire", inscrire);
    map.put("inscrireList", inscrireService.selectAll());
    return"inscrire/inscrire";
	}
	
	@RequestMapping(value="/nouvelle", method=RequestMethod.GET)
	public String addInscrire(Model model) {
		
		Inscrire inscrire=new Inscrire();
		List<Etudiant>etudiants=etudiantService.selectAll();
		if(etudiants ==null) {
			etudiants=new ArrayList<Etudiant>();
		}
		
		List<Residence> residences=residenceService.selectAll();
		if(residences ==null) {
			residences=new ArrayList<Residence>();
		}
		model.addAttribute("inscrire", inscrire);
		model.addAttribute("etudiants", etudiants);
		model.addAttribute("residences", residences);
		return"inscrire/AddInscrire";
	}
	@RequestMapping(value="/nouvelle", method=RequestMethod.POST)
	public String enregistrerInscrire(Inscrire inscrire) {
		if(inscrire.getIdInscription()  !=null) {
			inscrireService.update(inscrire);
		}else {
			inscrireService.save(inscrire);
		}
		return"redirect:/inscrire/";
	}
	@RequestMapping(value="/modifier/{idInscription}")
	public String modifierInscrire(Model model, @PathVariable Long idInscription) {
		if(idInscription !=null) {
			
			Inscrire inscrire=inscrireService.getById(idInscription);
			List<Residence>residences=residenceService.selectAll();
			if(residences ==null) {
				residences=new ArrayList<Residence>();
			}
			model.addAttribute("residences", residences);
			List<Etudiant> etudiants=etudiantService.selectAll();
			if(etudiants ==null) {
				etudiants=new ArrayList<Etudiant>();
			}
			model.addAttribute("etudiants", etudiants);
			if(inscrire !=null) {
				model.addAttribute("inscrire", inscrire);
			}
		}
		return "inscrire/AddInscrire";
	}
	@RequestMapping(value="/supprimer/{idInscription}")
	public String supprimerAffecter(Model model, @PathVariable Long idInscription) {
		if(idInscription !=null) {
			Inscrire inscrire=inscrireService.getById(idInscription);
			if(inscrire !=null) {
				inscrireService.delete(idInscription);
			}
		}
		return"redirect:/inscrire/";
	}
}