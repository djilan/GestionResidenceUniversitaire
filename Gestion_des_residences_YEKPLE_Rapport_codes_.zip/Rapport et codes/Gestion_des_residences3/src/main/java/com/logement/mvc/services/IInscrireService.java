package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Inscrire;

public interface IInscrireService {

    public Inscrire save(Inscrire entity);
	public Inscrire update(Inscrire entity);
	public List<Inscrire> selectAll();
	//Selectionner toutes les enregistrements en faisant le tri
	public List<Inscrire> selectAll(String sortField, String sort);
	public Inscrire getById(Long id);
	public void delete(Long id);
	// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
	public Inscrire findOne(String paramName, Object paramValue);
	public Inscrire findOne(String[] paramNames, Object[] paramValues);
}
