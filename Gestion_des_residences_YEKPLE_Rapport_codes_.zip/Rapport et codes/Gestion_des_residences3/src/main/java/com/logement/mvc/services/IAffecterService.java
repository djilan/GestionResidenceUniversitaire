package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Affecter;

public interface IAffecterService {

    public Affecter save(Affecter entity);
	
	public Affecter update(Affecter entity);
	
	public List<Affecter> selectAll();
	
	//Selectionner toutes les enregistrements en faisant le tri
	public List<Affecter> selectAll(String sortField, String sort);
	
	public Affecter getById(Long id);
	
	public void delete(Long id);
	
	// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
	
	public Affecter findOne(String paramName, Object paramValue);
	
	public Affecter findOne(String[] paramNames, Object[] paramValues);
}
