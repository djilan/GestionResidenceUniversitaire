package com.logement.mvc.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name="OPERATIONS")
public class Operations implements Serializable{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy=GenerationType.AUTO)
	private Long idOperation;
    
    private String operationCode;
  
	private String natureOperation;
 
	private String motif;
 
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date dateOperation;
    
    @ManyToOne
    @JoinColumn(name="code_etudiant")
    private Etudiant etudiant;
   
	public Long getIdOperation() {
		return idOperation;
	}
	public void setIdOperation(Long idOperation) {
		this.idOperation = idOperation;
	}
	public String getOperationCode() {
		return operationCode;
	}
	public void setOperationCode(String operationCode) {
		this.operationCode = operationCode;
	}
	public String getNatureOperation() {
		return natureOperation;
	}
	public void setNatureOperation(String natureOperation) {
		this.natureOperation = natureOperation;
	}
	public String getMotif() {
		return motif;
	}
	public void setMotif(String motif) {
		this.motif = motif;
	}


	public Date getDateOperation() {
		return dateOperation;
	}
	public void setDateOperation(Date dateOperation) {
		this.dateOperation = dateOperation;
	}
	public Etudiant getEtudiant() {
		return etudiant;
	}
	public void setEtudiant(Etudiant etudiant) {
		this.etudiant = etudiant;
	}
	public Operations() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	
}
