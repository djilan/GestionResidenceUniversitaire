package com.logement.mvc.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.logement.mvc.entities.Etudiant;
import com.logement.mvc.entities.Operations;
import com.logement.mvc.services.IEtudiantService;
import com.logement.mvc.services.IOperationsService;

@Controller

@RequestMapping(value="/operation")
public class OperationController {
    
	@Autowired
	private IOperationsService operationsService;
	@Autowired
	private IEtudiantService etudiantService;
	@RequestMapping(value="/")
	public String operation(Map<String , Object >map) {
		Operations operations=new Operations();
		map.put("operations", operations);
		map.put("operations", operationsService.selectAll());
		return"operation/operation";
	}
	@RequestMapping(value="/nouvelle", method=RequestMethod.GET)
	public String addOperation(Model model) {
		Operations operation=new Operations();
		List<Etudiant> etudiants=etudiantService.selectAll();
		if(etudiants ==null) {
			etudiants=new ArrayList<Etudiant>();
		}
		model.addAttribute("operation", operation);
		model.addAttribute("etudiants", etudiants);
		return "operation/AddOperation";
		
	}
	@RequestMapping(value="/nouvelle", method=RequestMethod.POST)
	public String enregistrerOperation(Operations operations) {
		if(operations.getIdOperation() !=null) {
			operationsService.update(operations);
		}else {
			operationsService.save(operations);
		}
		return"redirect:/operation/";
	}
	@RequestMapping(value="/modifier/{idOperation}")
	public String modifierOperation(Model model, @PathVariable Long idOperation) {
		if(idOperation!=null) {
			
			Operations operation=operationsService.getById(idOperation);
			List<Etudiant> etudiants=etudiantService.selectAll();
			if(etudiants ==null) {
				etudiants=new ArrayList<Etudiant>();
			}
			model.addAttribute("etudiants", etudiants);
			if(operation !=null) {
				model.addAttribute("operation", operation);
			}
		}
		return "operation/AddOperation";
	}
	@RequestMapping(value="/supprimer/{idOperation}")
	public String supprimerOperation(Model model, @PathVariable Long idOperation) {
		if(idOperation !=null) {
			Operations operation=operationsService.getById(idOperation);
			if(operation !=null) {
				operationsService.delete(idOperation);
			}
		}
		return"redirect:/operation/";
	}
	@RequestMapping(value="/etudiant")
	public String etudiant(Map<String , Object >map) {
	Etudiant etudiants =new Etudiant();
	map.put("etudiants", etudiants);
	map.put("etudiantsList", etudiantService.selectAll());
	return"etudiant/etudiant";
	}
}
