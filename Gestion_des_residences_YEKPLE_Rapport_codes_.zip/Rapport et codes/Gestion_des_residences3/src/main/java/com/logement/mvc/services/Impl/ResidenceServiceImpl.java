package com.logement.mvc.services.Impl;

import java.util.List;

import org.springframework.transaction.annotation.Transactional;

import com.logement.mvc.dao.IResidenceDao;
import com.logement.mvc.entities.Residence;
import com.logement.mvc.services.IResidenceService;
@Transactional
public class ResidenceServiceImpl implements IResidenceService {
    
	private IResidenceDao dao;
	
	public void setDao(IResidenceDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Residence save(Residence entity) {
		// TODO Auto-generated method stub
		return dao.save(entity);
	}

	@Override
	public Residence update(Residence entity) {
		// TODO Auto-generated method stub
		return dao.update(entity);
	}

	@Override
	public List<Residence> selectAll() {
		// TODO Auto-generated method stub
		return dao.selectAll();
	}

	@Override
	public List<Residence> selectAll(String sortField, String sort) {
		// TODO Auto-generated method stub
		return dao.selectAll(sortField, sort);
	}

	@Override
	public Residence getById(Long id) {
		// TODO Auto-generated method stub
		return dao.getById(id);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		dao.delete(id);
	}

	@Override
	public Residence findOne(String paramName, Object paramValue) {
		// TODO Auto-generated method stub
		return dao.findOne(paramName, paramValue);
	}

	@Override
	public Residence findOne(String[] paramNames, Object[] paramValues) {
		// TODO Auto-generated method stub
		return dao.findOne(paramNames, paramValues);
	}

}
