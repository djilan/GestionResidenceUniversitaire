package com.logement.mvc.services;

import java.util.List;

import com.logement.mvc.entities.Chambre;

public interface IChambreService {

	
	public Chambre save(Chambre entity);
	public Chambre update(Chambre entity);
	public List<Chambre> selectAll();
	//Selectionner toutes les enregistrements en faisant le tri
	public List<Chambre> selectAll(String sortField, String sort);
	public Chambre getById(Long id);
	public void delete(Long id);
	// C'est une methode qui permet de trouver un enregistrement a partir de sa valeur et le nom de son parametre
	public Chambre findOne(String paramName, Object paramValue);
	public Chambre findOne(String[] paramNames, Object[] paramValues);
}
