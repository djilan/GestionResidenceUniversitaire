package com.logement.mvc.dao;

import com.logement.mvc.entities.Operations;
/*Interface*/
public interface IOperationsDao extends IGenericDao<Operations>{

}
